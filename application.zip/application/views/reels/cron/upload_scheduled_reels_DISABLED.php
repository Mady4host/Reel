<?php
/*
 * سكربت الكرون لنشر الريلز المجدولة.
 * المسار الحالي (حسب طلبك): application/views/reels/cron/upload_scheduled_reels.php
 * الأفضل نقله خارج views لكن أبقيته كما طلبت.
 *
 * طريقة الاستدعاء (CLI):
 * /usr/bin/php /home/social/public_html/index.php reels cron_publish YOUR_TOKEN
 *
 * أو تشغيل هذا الملف مباشرة بـ php (لو ضبطت الـ include path لبيئة CodeIgniter شيء آخر).
 * لكن يفضل تستخدم ميثود الكنترولر (cron_publish) الموضح في Reels.php.
 */

/////////////////////// إعدادات الاتصال ///////////////////////
$DB_HOST = 'localhost';
$DB_USER = 'DB_USER';
$DB_PASS = 'DB_PASS';
$DB_NAME = 'DB_NAME';

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_errno) {
    error_log('[CRON REELS] DB Connection failed: ' . $mysqli->connect_error);
    exit;
}

// قفل لحماية من التوازي
$lockFile = __DIR__ . '/upload_reels.lock';
$lockHandle = fopen($lockFile, 'c+');
if (!$lockHandle || !flock($lockHandle, LOCK_EX | LOCK_NB)) {
    // هناك عملية أخرى تعمل
    exit;
}

// الحد الأقصى للمحاولات
$MAX_ATTEMPTS = 5;

// جلب الريلز المستحقة (حيث الوقت <= الآن + pending + ليست قيد المعالجة)
$sql = "SELECT * FROM scheduled_reels 
        WHERE status='pending' 
          AND processing=0 
          AND scheduled_time <= NOW()
        ORDER BY scheduled_time ASC
        LIMIT 20";

$result = $mysqli->query($sql);
if (!$result) {
    error_log('[CRON REELS] Query error: '.$mysqli->error);
    flock($lockHandle, LOCK_UN);
    fclose($lockHandle);
    exit;
}

while ($row = $result->fetch_assoc()) {

    $scheduled_id = (int)$row['id'];

    // ضع processing=1 لتأمين السطر
    $mysqli->query("UPDATE scheduled_reels SET processing=1 WHERE id={$scheduled_id} AND processing=0");
    if ($mysqli->affected_rows === 0) {
        continue; // تمت معالجته في عملية أخرى
    }

    $attempt_number = (int)$row['attempt_count'] + 1;
    $time_now = date('Y-m-d H:i:s');

    $mysqli->query("UPDATE scheduled_reels 
                    SET attempt_count={$attempt_number}, last_attempt_at='{$time_now}' 
                    WHERE id={$scheduled_id}");

    $video_path_abs = realpath(__DIR__ . '/../../../../') . '/' . $row['video_path']; 
    // مسار الجذر: __DIR__ = .../application/views/reels/cron
    // ../../../../ للخروج حتى public_html (تأكد أنه صحيح لمسارك)

    if (!$video_path_abs || !file_exists($video_path_abs)) {
        $msg = 'الملف غير موجود: ' . $row['video_path'];
        logAttempt($mysqli, $scheduled_id, $row['user_id'], $row['fb_page_id'], $attempt_number, 'failed', $msg);
        failOrRetry($mysqli, $scheduled_id, $attempt_number, $msg, $MAX_ATTEMPTS);
        continue;
    }

    // TODO: هنا اكتب استدعاء Facebook Graph API الحقيقي
    // محاكاة نشر (ضع $apiSuccess = true عند النجاح)
    $apiSuccess = true;
    $apiVideoId = 'VID'.time().rand(100,999);
    $apiMessage = 'تم النشر بنجاح (محاكاة)';

    if ($apiSuccess) {
        $published_time = date('Y-m-d H:i:s');
        $stmt = $mysqli->prepare("UPDATE scheduled_reels 
            SET status='uploaded', fb_response=?, published_time=?, processing=0 
            WHERE id=?");
        $stmt->bind_param('ssi', $apiVideoId, $published_time, $scheduled_id);
        $stmt->execute();

        logAttempt($mysqli, $scheduled_id, $row['user_id'], $row['fb_page_id'], $attempt_number, 'success', $apiMessage.' | VIDEO_ID='.$apiVideoId);
    } else {
        $errorMsg = 'فشل النشر: (استبدل برسالة الخطأ)';
        logAttempt($mysqli, $scheduled_id, $row['user_id'], $row['fb_page_id'], $attempt_number, 'failed', $errorMsg);
        failOrRetry($mysqli, $scheduled_id, $attempt_number, $errorMsg, $MAX_ATTEMPTS);
    }
}

flock($lockHandle, LOCK_UN);
fclose($lockHandle);

/////////////////////// دوال مساعدة ///////////////////////

function logAttempt($mysqli, $scheduled_id, $user_id, $fb_page_id, $attempt_number, $status, $message) {
    $stmt = $mysqli->prepare("INSERT INTO scheduled_reels_logs 
        (scheduled_reel_id, user_id, fb_page_id, attempt_number, status, message) 
        VALUES (?,?,?,?,?,?)");
    $stmt->bind_param('iisiis', $scheduled_id, $user_id, $fb_page_id, $attempt_number, $status, $message);
    $stmt->execute();
}

function failOrRetry($mysqli, $scheduled_id, $attempt_number, $msg, $MAX_ATTEMPTS) {
    if ($attempt_number >= $MAX_ATTEMPTS) {
        $stmt = $mysqli->prepare("UPDATE scheduled_reels 
            SET status='failed', last_error=?, processing=0 
            WHERE id=?");
        $stmt->bind_param('si', $msg, $scheduled_id);
    } else {
        $stmt = $mysqli->prepare("UPDATE scheduled_reels 
            SET status='pending', last_error=?, processing=0 
            WHERE id=?");
        $stmt->bind_param('si', $msg, $scheduled_id);
    }
    $stmt->execute();
}